
const lms=['LM 1.1','LM 1.2','LM 1.3','LM 2.1','LM 2.2'];
const el=document.getElementById('forms');
lms.forEach(v=>{
 el.innerHTML+=`<div class="card"><h3>${v}</h3>
 <input placeholder="Deskripsi">
 <input type="number" placeholder="Target">
 <input type="number" placeholder="Realisasi">
 <input type="file"></div>`;
});
